#!/bin/bash
# Runs J2ME Loader from this folder with the system Java (17 or newer),
# outside PortMaster (desktop Linux, other handheld firmwares).
#   ./run.sh [game.jar]
cd "$(dirname "$0")"
HOME_DIR=$(pwd)
mkdir -p games data config/games screenshots
ARGS=()
[ -n "$1" ] && ARGS=("$(readlink -f "$1")")
while true; do
	java -Xms32m -Xmx256m -Xss1m -XX:+UseSerialGC -XX:+UnlockDiagnosticVMOptions -XX:-BytecodeVerificationRemote \
		-Djlr.home="$HOME_DIR" -Djlr.lib.dir="$HOME_DIR/lib" -cp "$HOME_DIR/jlr.jar" jlr.Main "${ARGS[@]}"
	code=$?
	if [ $code -eq 101 ]; then
		ARGS=()
	elif [ $code -eq 102 ] && [ -f .next ]; then
		mapfile -t ARGS < .next
		rm -f .next
	else
		exit $code
	fi
done
