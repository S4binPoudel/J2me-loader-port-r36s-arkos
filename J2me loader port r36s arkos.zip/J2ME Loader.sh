#!/bin/bash
# J2ME Loader for R36S / ArkOS (PortMaster port)
#
#   "J2ME Loader.sh"                 opens the game browser
#   "J2ME Loader.sh" /path/game.jar  starts a game directly (EmulationStation)
#
# Games: put .jar (and optional .jad) files into ports/j2meloader/games
# (or /roms/j2me, which is scanned too).

# PortMaster preamble
XDG_DATA_HOME=${XDG_DATA_HOME:-$HOME/.local/share}
if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
elif [ -d "$XDG_DATA_HOME/PortMaster/" ]; then
  controlfolder="$XDG_DATA_HOME/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi
source $controlfolder/control.txt
[ -f "${controlfolder}/mod_${CFW_NAME}.txt" ] && source "${controlfolder}/mod_${CFW_NAME}.txt"
get_controls

GAMEDIR="/$directory/ports/j2meloader"
java_runtime="zulu17.54.21-ca-jre17.0.13-linux"

cd "$GAMEDIR"
> "$GAMEDIR/log.txt" && exec > >(tee "$GAMEDIR/log.txt") 2>&1
mkdir -p "$GAMEDIR/games" "$GAMEDIR/data" "$GAMEDIR/config/games" "$GAMEDIR/screenshots"

# Java runtime (shared PortMaster squashfs)
export JAVA_HOME="/tmp/javaruntime/"
$ESUDO mkdir -p "${JAVA_HOME}"
if [ ! -f "$controlfolder/libs/${java_runtime}.squashfs" ]; then
  if [ ! -f "$controlfolder/harbourmaster" ]; then
    pm_message "This port requires the latest PortMaster to run, please go to https://portmaster.games/ for more info."
    sleep 5
    exit 1
  fi
  $ESUDO $controlfolder/harbourmaster --quiet --no-check runtime_check "${java_runtime}.squashfs"
fi
if [[ "$PM_CAN_MOUNT" != "N" ]]; then
  $ESUDO umount "${JAVA_HOME}" 2>/dev/null
fi
$ESUDO mount "$controlfolder/libs/${java_runtime}.squashfs" "${JAVA_HOME}"
export PATH="$JAVA_HOME/bin:$PATH"

if [ ! -x "$JAVA_HOME/bin/java" ]; then
  pm_message "Java runtime ${java_runtime} could not be mounted."
  sleep 5
  exit 1
fi

# Controls are read directly through SDL (no gptokeyb needed):
# SELECT = menu, START = phone keypad, SELECT+START = quit.
export SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig"
DB_OPT=""
[ -f "$controlfolder/gamecontrollerdb.txt" ] && DB_OPT="-Djlr.gamecontrollerdb=$controlfolder/gamecontrollerdb.txt"

GAME_DIRS="$GAMEDIR/games"
for d in "/$directory/j2me" /roms/j2me /roms2/j2me; do
  [ -d "$d" ] && case ":$GAME_DIRS:" in *":$d:"*) ;; *) GAME_DIRS="$GAME_DIRS:$d" ;; esac
done

type pm_platform_helper >/dev/null 2>&1 && pm_platform_helper "$JAVA_HOME/bin/java"

# The R36S has 1 GB of RAM: a small heap and the serial collector keep the
# VM lean. Bytecode verification is relaxed like on the phones (old
# obfuscators produce code the modern verifier rejects).
JAVA_OPTS="-Xms32m -Xmx256m -Xss1m -XX:+UseSerialGC -XX:+UnlockDiagnosticVMOptions -XX:-BytecodeVerificationRemote \
  -Djava.awt.headless=true -Djlr.home=$GAMEDIR -Djlr.lib.dir=$GAMEDIR/lib -Djlr.games=$GAME_DIRS $DB_OPT"

ARGS=()
if [ -n "$1" ] && [ -f "$1" ]; then
  ARGS=("$1")
fi

# 0 = quit, 101 = back to the game browser, 102 = run what .next says
while true; do
  java $JAVA_OPTS -cp "$GAMEDIR/jlr.jar" jlr.Main "${ARGS[@]}"
  code=$?
  echo "J2ME Loader exited with $code"
  if [ $code -eq 101 ]; then
    ARGS=()
  elif [ $code -eq 102 ] && [ -f "$GAMEDIR/.next" ]; then
    mapfile -t ARGS < "$GAMEDIR/.next"
    rm -f "$GAMEDIR/.next"
  else
    break
  fi
done

if [[ "$PM_CAN_MOUNT" != "N" ]]; then
  $ESUDO umount "${JAVA_HOME}"
fi
pm_finish
